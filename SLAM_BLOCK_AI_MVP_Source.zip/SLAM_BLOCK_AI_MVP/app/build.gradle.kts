plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.slamblockai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.slamblockai"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2-mvp"
    }
}
dependencies {
    implementation("com.google.mlkit:pose-detection-accurate:18.0.0-beta5")
}
