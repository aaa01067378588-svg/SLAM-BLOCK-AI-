package com.example.slamblockai

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.google.mlkit.vision.pose.PoseLandmark

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: TextView? = null
    private var lastAlert = 0L
    private var raisedLastFrame = false
    private var busy = false
    private val channelId = "slam_block_ai"
    private val detector by lazy {
        val options = PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
            .build()
        PoseDetection.getClient(options)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("SLAM BLOCK AI")
            .setContentText("화면 동작 분석 실행 중")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, notification)

        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("captureData")
        if (resultCode == Activity.RESULT_OK && data != null) {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(Looper.getMainLooper()))
            startCapture()
            addOverlay()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (busy) { image.close(); return@setOnImageAvailableListener }
            busy = true
            val bitmap = imageToBitmap(image)
            image.close()
            if (bitmap == null) { busy = false; return@setOnImageAvailableListener }
            val input = InputImage.fromBitmap(bitmap, 0)
            detector.process(input)
                .addOnSuccessListener { pose -> inspectPose(pose, height.toFloat()) }
                .addOnFailureListener { updateOverlay("분석 중…") }
                .addOnCompleteListener {
                    bitmap.recycle()
                    busy = false
                }
        }, Handler(Looper.getMainLooper()))

        display = projection?.createVirtualDisplay(
            "SlamBlockScreen", width, height, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null
        )
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride
            val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            Bitmap.createScaledBitmap(cropped, (image.width * 0.55f).toInt().coerceAtLeast(1),
                (image.height * 0.55f).toInt().coerceAtLeast(1), true).also { cropped.recycle() }
        } catch (_: Exception) { null }
    }

    private fun inspectPose(pose: Pose, frameHeight: Float) {
        val leftShoulder = pose.getPoseLandmark(PoseLandmark.LEFT_SHOULDER)
        val rightShoulder = pose.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER)
        val leftWrist = pose.getPoseLandmark(PoseLandmark.LEFT_WRIST)
        val rightWrist = pose.getPoseLandmark(PoseLandmark.RIGHT_WRIST)
        val shoulders = listOfNotNull(leftShoulder, rightShoulder)
        val wrists = listOfNotNull(leftWrist, rightWrist)
        val shoulderY = shoulders.map { it.position.y }.average().toFloat()
        val threshold = frameHeight * 0.035f
        val armRaised = wrists.any { it.position.y < shoulderY - threshold }
        val now = SystemClock.elapsedRealtime()

        if (armRaised && !raisedLastFrame && now - lastAlert > 1300L) {
            lastAlert = now
            vibrate()
            updateOverlay("팔 들기 감지 · 블락 타이밍 확인!")
        } else if (!armRaised) {
            updateOverlay("감지 대기 중")
        }
        raisedLastFrame = armRaised
    }

    private fun vibrate() {
        val vibrator = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as Vibrator)
        }
        if (Build.VERSION.SDK_INT >= 26)
            vibrator.vibrate(VibrationEffect.createOneShot(90, VibrationEffect.DEFAULT_AMPLITUDE))
        else @Suppress("DEPRECATION") vibrator.vibrate(90)
    }

    private fun addOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "BLOCK AI · 감지 대기 중"
            textSize = 12f; setTextColor(Color.WHITE)
            setPadding(16, 10, 16, 10)
            setBackgroundColor(0xCC172433.toInt())
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 100 }
        try { wm.addView(overlay, params) } catch (_: Exception) {}
    }

    private fun updateOverlay(message: String) {
        Handler(Looper.getMainLooper()).post { overlay?.text = "BLOCK AI · $message" }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "SLAM BLOCK AI", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } }
        catch (_: Exception) {}
        display?.release()
        reader?.close()
        projection?.stop()
        detector.close()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
