package com.example.slamblockai

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val captureRequest = 41
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(17, 25, 35))
        }
        fun addText(value: String, size: Float, color: Int = Color.WHITE) {
            root.addView(TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                setPadding(0, 8, 0, 8)
            })
        }
        addText("SLAM BLOCK AI", 28f)
        addText("슛 동작 보조 감지 · 실험 버전", 16f, Color.LTGRAY)
        status = TextView(this).apply {
            text = "상태: 준비됨"
            textSize = 18f; setTextColor(Color.rgb(90, 220, 160))
            setPadding(0, 22, 0, 18)
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "1. 화면 위 표시 권한 설정"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else status.text = "상태: 화면 위 표시 허용됨"
            }
        })
        root.addView(Button(this).apply {
            text = "2. 감지 시작"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "먼저 화면 위 표시 권한을 허용하세요."
                    return@setOnClickListener
                }
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        })
        root.addView(Button(this).apply {
            text = "감지 중지"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "상태: 중지됨"
            }
        })
        addText(
            "감지 방식: 화면에서 가장 뚜렷한 사람의 팔이 어깨보다 올라가는 동작을 찾습니다. " +
            "슛 동작 전용 AI가 아니므로 다른 동작도 감지할 수 있고, 모든 장면에서 동작하지 않을 수 있습니다.",
            14f, Color.LTGRAY
        )
        setContentView(root)
    }

    @Deprecated("Legacy callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("captureData", data)
            }
            startForegroundService(service)
            status.text = "상태: 화면 분석 중"
        }
    }
}
